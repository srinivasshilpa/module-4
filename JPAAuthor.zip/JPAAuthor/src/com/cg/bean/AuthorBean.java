package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="author") 
@NamedQuery(name="displayAuthor",query="from AuhtorBean")
public class AuthorBean {
	
     @Id
     @GeneratedValue(strategy=GenerationType.AUTO)
     @Column(name="author_id")
     private int authorId;
     
     @Column(name="first_name")
     private String firstName;
     
     @Column(name="middle_name")
     private String middleName;
     
     @Column(name="last_name")
     private String lastName;
     
     @Column(name="phone_no")
     private int phoneNo;
	
     public AuthorBean() {
		super();
	}
	
     public AuthorBean(int authorId, String firstName, String lastName,
			String middleName, int phoneNo) {
		super();
		this.authorId = authorId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.phoneNo = phoneNo;
	}
	
     public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	@Override
	public String toString() {
		return "AuthorBean [authorId=" + authorId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", middleName=" + middleName
				+ ", phoneNo=" + phoneNo + "]";
	}
     
}
