package com.author.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.bean.AuthorBean;

public class AuthorDAOImpl implements IAuthorDAO {
  
	private EntityManager entitymanager;

	public AuthorDAOImpl() {
		entitymanager = JPAUtil.getEntityManager();
	}
	
	@Override
	public int addAuthor(AuthorBean author) {
		entitymanager.persist(author);
		entitymanager.getTransaction().begin();
		entitymanager.getTransaction().commit();
		return author.getAuthorId();
	}

	@Override
	public AuthorBean deleteAuthor(int authorId) {
		entitymanager.getTransaction().begin();
		AuthorBean author = entitymanager.find(AuthorBean.class, authorId);
		if(author==null){
			return null;
		}else{
			entitymanager.remove(authorId);
			entitymanager.getTransaction().commit();
			return author;
		}
	}

	@Override
	public AuthorBean findAuthor(int authorId) {
		entitymanager.getTransaction().begin();
		AuthorBean author = entitymanager.find(AuthorBean.class, authorId);
		if(author==null){
			return null;
		}else{
			
			entitymanager.getTransaction().commit();
			return author;
		}
	}
	

	@Override
	public List<AuthorBean> displayAuthor() {
		     entitymanager.getTransaction().begin();
			  Query qry = entitymanager.createQuery("from AuthorBean");    
			  
			  List list = qry.getResultList();
			  
			 entitymanager.getTransaction().commit();
			 return list;
	}

}
