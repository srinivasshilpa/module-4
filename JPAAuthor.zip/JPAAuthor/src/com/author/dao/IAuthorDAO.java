package com.author.dao;

import java.util.List;

import com.author.exception.AuthorException;
import com.cg.bean.AuthorBean;

public interface IAuthorDAO {
    public int addAuthor(AuthorBean author) throws AuthorException;
    
    public AuthorBean deleteAuthor(int authorId) throws AuthorException;
    
    public AuthorBean findAuthor(int authorId) throws AuthorException;
    
    public List<AuthorBean> displayAuthor() throws AuthorException;
    
}
