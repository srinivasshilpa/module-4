package com.author.service;

import java.util.List;

import com.author.dao.AuthorDAOImpl;
import com.author.dao.IAuthorDAO;
import com.author.exception.AuthorException;
import com.cg.bean.AuthorBean;

public class AuthorServiceImpl implements IAuthorService {
    IAuthorDAO authorDao = new AuthorDAOImpl();
	@Override
	public int addAuthor(AuthorBean author) throws AuthorException {
		return authorDao.addAuthor(author);
	}

	@Override
	public AuthorBean deleteAuthor(int authorId) throws AuthorException {
		return authorDao.deleteAuthor(authorId);
	}

	@Override
	public AuthorBean findAuthor(int authorId) throws AuthorException {
		return authorDao.findAuthor(authorId);
	}

	@Override
	public List<AuthorBean> displayAuthor() throws AuthorException {
		return authorDao.displayAuthor();
	}

}
