package com.author.client;

import java.util.List;
import java.util.Scanner;

import com.author.exception.AuthorException;
import com.author.service.AuthorServiceImpl;
import com.author.service.IAuthorService;
import com.cg.bean.AuthorBean;

public class Client {
      public static void main(String[] args) throws AuthorException{
    	  IAuthorService service = new AuthorServiceImpl();
    	  
    	  System.out.println("1:Add Author \n2:Delete Author \n3:Find Author \n4:Display all Authors");
    	  Scanner in = new Scanner(System.in);
    	  int ch=in.nextInt();
    	  
    	  AuthorBean bean = new AuthorBean();
    	  switch(ch)
    	  {
    	  case 1:
    		  
    		  System.out.println("Enter the first name");
    		  String fname = in.nextLine();
    		  in.next();
    		  bean.setFirstName(fname);
    		  
    		  System.out.println("Enter the middle name");
    		  String mname = in.nextLine();
    		  in.next();
    		  bean.setLastName(mname);
    		  
    		  System.out.println("Enter the last name");
    		  String lname = in.nextLine();
    		  in.next();
    		  bean.setLastName(lname);
    		  
    		  System.out.println("Enter the phone number");
    		  int  num = in.nextInt();
    		  in.next();
    		  bean.setPhoneNo(num);
    		  
    		  int aid=service.addAuthor(bean);
    		  
    		  System.out.println("Inserted author with author id: "+aid);
    		  
    		  break;
    	  case 2:
    		  System.out.println("Enter the Author Id:");
    		  int id = in.nextInt();
    		  bean = service.deleteAuthor(id);
    		  if(bean == null){
    			  System.out.println("Author not found");
    		  }else{
    			  System.out.println("Deleted successfully!");
    			  System.out.println("The deleted author Id is "+bean.getAuthorId()+" Author name is "+bean.getFirstName()+" "+bean.getMiddleName()+" "+bean.getLastName()+". Phone number is "+bean.getPhoneNo());
    		  }
    		  
    		  break;
    	  case 3:
    		  System.out.println("Enter the Author Id:");
    		  int no = in.nextInt();
    		  bean = service.findAuthor(no);
    		  if(bean == null){
    			  System.out.println("Author not found");
    		  }else{
    			  System.out.println("Found successfully!");
    			  System.out.println("The author Id is "+bean.getAuthorId()+" Author name is "+bean.getFirstName()+" "+bean.getMiddleName()+" "+bean.getLastName()+". Phone number is "+bean.getPhoneNo());
    		  }
    		  break;
    	  case 4:
    		  
   		   List<AuthorBean> list = service.displayAuthor();
   		   
   		   for(AuthorBean author : list)
   		   {
   			   
   			 System.out.println(author.getAuthorId()+" "+author.getFirstName()+" "+author.getMiddleName()+" "+author.getLastName()+" phone number is"+author.getPhoneNo());
   			   
   		   }
   		   break;
    	  case 5:
    		  System.exit(0);
    	    break;
    	  }
    	  in.close();
      }
}
