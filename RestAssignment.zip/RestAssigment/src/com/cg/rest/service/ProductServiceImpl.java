package com.cg.rest.service;

import java.util.List;

import com.cg.rest.bean.Product;
import com.cg.rest.dao.IProductDAO;
import com.cg.rest.dao.ProductDAOImpl;

public class ProductServiceImpl implements IProductService {
     
	 IProductDAO dao;
	   
	   public ProductServiceImpl() {
		    
		   dao = new ProductDAOImpl();
		   
	   }
	   
	
	public List<Product> getAllProducts() {
		return dao.getAllProducts();
	}

	
	public Product getProduct(int id) {
		return dao.getProduct(id);
	}

	
	public Product addProduct(Product product) {
		return dao.addProduct(product);
	}

	
	public Product deleteProduct(int id) {
		return dao.deleteProduct(id);
	}

}
