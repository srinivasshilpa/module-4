package com.cg.rest.service;

import java.util.List;

import com.cg.rest.bean.Product;

public interface IProductService {
	public List<Product> getAllProducts();
	public Product getProduct(int id);
	public Product addProduct(Product product);
	public Product deleteProduct(int id);
}
