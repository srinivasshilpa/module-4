package com.cg.rest.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.rest.bean.Product;
import com.cg.rest.staticDB.ProductDB;

public class ProductDAOImpl implements IProductDAO {
	static HashMap<Integer, Product> productIdMap = ProductDB.getProductIdMap();
	@Override
	public List<Product> getAllProducts() {
		List<Product> products = new ArrayList<Product>(productIdMap.values());
		return products;
	}

	@Override
	public Product getProduct(int id) {
		Product product = productIdMap.get(id);
		return product;
	}

	@Override
	public Product addProduct(Product product) {
		 productIdMap.put(product.getProductId(), product);
		 return product;
	}

	@Override
	public Product deleteProduct(int id) {
		return productIdMap.remove(id);
	}
	
	public Product updateProduct(Product product) {
		if (product.getProductId() <= 0)
			return null;
		productIdMap.put(product.getProductId(), product);
		return product;

	}


}
