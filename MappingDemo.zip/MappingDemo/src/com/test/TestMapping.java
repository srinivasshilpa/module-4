package com.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestMapping {
    public static void main(String[] args) {
    	 EntityManagerFactory emf =Persistence.createEntityManagerFactory("JPA-PU");
		  EntityManager em = emf.createEntityManager();
		  em.getTransaction().begin();//transaction boundary begins
		  
		  	
		//String qrystr="from Employee where department.departmentId > 1";
		
		Query qrystr=em.createQuery("from Employee where department.departmentId > 1");   
		 List list = qrystr.getResultList();
		  
		  for(Object obj : list)
		  {
			   Employee emp=(Employee) obj;
			   System.out.println(emp.getEmployeeId()+" "+emp.getEmployeeName()+" "+emp.getDepartment().getDepartmentName());
		  }
		 
		  
		  
		   em.close();
		   emf.close();
	}
}
