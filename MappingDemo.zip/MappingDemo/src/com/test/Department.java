package com.test;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity  
@Table(name="dept_tbl")
public class Department {
    @Id
    @GeneratedValue
    @Column (name="dept_id")
	private int departmentId;
    
    @Column(name="dept_name" ,length=10)
	private String departmentName;
    
    @OneToOne(mappedBy="department")  //bidirectional-- it should not go for new eployee table,, it should go for the old one
    private Employee employee;        //so we give mappedBy
    
    
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
    
    
}
