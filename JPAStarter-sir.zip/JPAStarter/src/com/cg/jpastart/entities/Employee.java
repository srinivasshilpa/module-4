package com.cg.jpastart.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="employee_tbl")  //to add table explicitly
@NamedQuery(name="viewAllEmployee",query="from Employee")
public class Employee {
	 @Id  //primary key
	 @GeneratedValue(strategy=GenerationType.AUTO)//auto is default if strategy is not specified
	 @Column(name="emp_id")
     private int employeeId;
	 
	 @Column(name="emp_name", length=15)
     private String employeeName;
	 
	 @Column(name="emp_sal")
	 @Transient  // salary will not be updated if it is transient
     private int employeeSalary;
	
     public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	
	public Employee() {
		super();
	}
	
	
	public Employee(int employeeId, String employeeName, int employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}
     
}
