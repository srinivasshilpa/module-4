package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EmployeeTest {
     public static void main(String[] args) {
		  EntityManagerFactory emf =Persistence.createEntityManagerFactory("JPA-PU");
		  EntityManager em = emf.createEntityManager();
		  em.getTransaction().begin();//transaction boundary begins
		      
		  Employee emp = new Employee();
		  emp.setEmployeeName("vijay");
		  emp.setEmployeeSalary(90000);
		   em.persist(emp);
		  em.getTransaction().commit();
		  
		System.out.println("Employee added to database");
		  em.close();
		  emf.close();
	}
}
